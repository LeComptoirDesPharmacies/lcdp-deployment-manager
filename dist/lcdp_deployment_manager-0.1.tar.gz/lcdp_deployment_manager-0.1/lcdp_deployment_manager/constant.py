# Constant.py

# Color
BLUE = 'BLUE'
GREEN = 'GREEN'

# Target group
TARGET_GROUP_COLOR_TAG_NAME = 'Color'
TARGET_GROUP_TYPE_TAG_NAME = 'Type'
TARGET_GROUP_DEFAULT_TYPE = 'default'
TARGET_GROUP_GATEWAY_TYPE = 'gateway'

# ECR
ECR_SERVICE_PREFIX = 'lcdp-'

# ECS
DEFAULT_DESIRED_COUNT = 2
HEALTHCHECK_RETRY_LIMIT = 26
HEALTHCHECK_SLEEPING_TIME = 30

# SES
FROM_MAIL = 'no-reply@lecomptoirdespharmacies.fr'
DEVELOPERS_MAIL = 'webmaster@lecomptoirdespharmacies.fr'
DEFAULT_CHARSET = 'UTF-8'
